create table sayings
(
    saying varchar(255) collate utf8mb4_general_ci not null comment '格言内容'
        primary key
)
    comment '格言表';


